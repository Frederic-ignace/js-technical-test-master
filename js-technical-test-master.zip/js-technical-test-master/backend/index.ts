//module import
import server from './src/utils/server';
server.start();