interface Image {
  id: number;
  name: string;
  path: string;
}

export default Image;
