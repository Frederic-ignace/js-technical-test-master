export type Server = {
	http: any;
	start: any;
}