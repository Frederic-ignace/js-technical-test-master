export const  serverProperty ={
    port:  4000,
    host: "localhost",
  }