#!/bin/sh
# remove_gitkeep.sh

# Remove the specified file
rm -f /var/lib/mysql/.gitkeep
