/// <reference types="vite-plugin-svgr/client" />
